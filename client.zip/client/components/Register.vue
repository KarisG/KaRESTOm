<template>
    <div>
        <nav class="menu" role="navigation">		
            <div class="inner">	
                <div class="m-left">
                    <p>{{commandeoption.monEmail}}</p>
                </div>	
                <div class="m-right">
                    <router-link to='/' class="m-link">Accueil</router-link>
                    <router-link to='/histoire' class="m-link">Histoire du site</router-link>
                    <router-link to='/Menu' class="m-link">Menu</router-link>
                    <router-link to='/commande' class="m-link">Ma commande</router-link>
                    <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
                </div>	                				
            </div>			
        </nav>
        <div class="contenu">
            <div class="fond">
                <h1>S'inscrire</h1>
                <button><router-link to='/connexion'>Annuler</router-link></button>
                <h2>Saisir votre email : <input type="text" v-model="user.email"> Saisir un mot de passe : <input type="text" v-model="user.password"><h2>
                <button @click="enregistrer()">Inscription</button>
            </div>
        </div>
    </div>
</template>

<script>
module.exports={
    props: {
        commandeoption: {type: Object},
        recettes: { type: Array, default: [] },
        commande: { type: Object },
    },
    data () {
        return {
            user: {
                email: '',
                password: ''
            },
        }
  },
  methods: {
      enregistrer(){
        this.$emit('add-user', this.user)
        this.user = {
            email: '',
            password: ''
        }
      }  
  }
}
</script>

<style scoped>



h1{
    text-align: center;
}

.fond{
	max-width: 1500px;
	margin-left: auto;
	margin-right: auto;
	background-color: white;
	box-shadow: 1px 2px 9px 0px rgba(0,0,0,0.75);
	padding:10px;
	margin-top: 50px;
	margin-bottom: 50px
}

button{
    padding: 10px;
    display: block;
    margin: auto;
}

</style>