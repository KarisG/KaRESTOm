<template>
  <div>
    <nav class="menu" role="navigation">		
      <div class="inner">		
        <div class="m-left">
            <p>{{commandeoption.monEmail}}</p>
        </div>
        <div class="m-right">
            <router-link to='/' class="m-link">Accueil</router-link>
            <router-link to='/histoire' class="m-link">Histoire du site</router-link>
            <router-link to='/Menu' class="m-link">Menu</router-link>
            <router-link to='/commande' class="m-link">Ma commande</router-link>
            <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
        </div>	                				
      </div>			
    </nav>
    <div class="contenu">
      <div class="carte">
        <div>
          <h2>Ma commande</h2>
          <p>Prix de ma commande : {{commandeoption.prix}}€</p>
          <button class="buttonCenter" @click="valider()">Valider ma commande</button>
        </div>
        <div class="fond">
            <h2>Mes entrées</h2>
            <div v-for="recette in commande.recettes" :key="recette.id">
                <div v-if="transition(recette.id).type == 0">
                  <div class="recette-img">
                    <div :style="{ backgroundImage: 'url(' + transition(recette.id).image + ')' }">
                    </div>
                  </div>
                  <div class="recette-content">
                    <div class="recette-title">
                      <h2>{{ transition(recette.id).name }} - {{ transition(recette.id).price }}€ : {{ recette.number }} </h2>
                    </div>
                  </div>
                </div>
            </div>
        </div>
        <div class="fond">
            <h2>Les plats</h2>
            <div v-for="recette in commande.recettes" :key="recette.id">
                <div v-if="transition(recette.id).type == 1">
                  <div class="recette-img">
                    <div :style="{ backgroundImage: 'url(' + transition(recette.id).image + ')' }">
                    </div>
                  </div>
                  <div class="recette-content">
                    <div class="recette-title">
                      <h2>{{ transition(recette.id).name }} - {{ transition(recette.id).price }}€ : {{ recette.number }} </h2>
                    </div>
                  </div>
                </div>
            </div>
        </div>
        <div class="fond">
            <h2>Les desserts</h2>
            <div v-for="recette in commande.recettes" :key="recette.id">
                <div v-if="transition(recette.id).type == 2">
                  <div class="recette-img">
                    <div :style="{ backgroundImage: 'url(' + transition(recette.id).image + ')' }">
                    </div>
                  </div>
                  <div class="recette-content">
                    <div class="recette-title">
                      <h2>{{ transition(recette.id).name }} - {{ transition(recette.id).price }}€ : {{ recette.number }} </h2>
                    </div>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
module.exports = {
  props: {
    commandeoption: {type: Object},
    recettes: { type: Array, default: [] },
    commande: { type: Object },
  },
  data () {
    return {
    }
  },
  async mounted () {
  },
  methods: {
    transition: function(recetteId){
      const recette = this.recettes.find(a => a.id === recetteId)
      return recette
    },
    valider: function(){
      this.$emit('valider-commande')
    }
  }
}
</script>

<style scoped>


</style>
