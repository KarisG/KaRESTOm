const recettes = [
  {
    id: 1,
    name: 'Foie gras de canard au cacao',
    image: 'http://leblogdufoiegras.com/wp-content/uploads/2016/10/Foie-Gras-%C3%A0-la-normande-cappu-de-FG-sorbet-pomme-verte-manazna-poop-con-Cifog-Asset-Adocom-2.jpg',
    price: 14,
    type: 0 //0 = entrée, 1 = plat, 2 = dessert
  },
  {
    id: 2,
    name: 'Saumon Ecossais',
    image: 'http://www.restaurantsparisiens.com/auberge-du-bonheur/wp-content/uploads/sites/6/2018/01/2987-BD-1.jpg',
    price: 16,
    type: 0
  },
  {
    id: 3,
    name: 'Six escargots de Bourgogne',
    image: 'https://i.pinimg.com/564x/e7/ff/cf/e7ffcf4b3bf3ca2af865dbde8c1c34d4.jpg',
    price: 13,
    type: 0
  },
  {
    id: 4,
    name: 'Tartines de chèvre chaud',
    image: 'https://www.soignon.fr/media/cache/resolve/medium_filter/uploads/Recettes/Recette-soignon-tartine-de-ch%25C3%25A8vre-chaud.jpg',
    price: 12,
    type: 0
  },
  {
    id: 5,
    name: 'Carpaccio à l\'italienne',
    image: 'https://img.cuisineaz.com/610x610/2016-10-22/i106405-carpaccio-de-boeuf-au-parmesan-releve-au-citron.jpg',
    price: 21,
    type: 1
  },
  {
    id: 6,
    name: 'Burger au fois gras',
    image: 'https://media-cdn.tripadvisor.com/media/photo-s/0f/56/00/de/burger-au-foie-gras-et.jpg',
    price: 22,
    type: 1
  },
  {
    id: 7,
    name: 'La côte de boeuf simmental de Bavière 1 KG (à partager à deux)',
    image: 'http://www.restaurantsparisiens.com/le-boeuf-maillot/wp-content/uploads/sites/7/2018/01/7014-BD.jpg',
    price: 29,
    type: 1
  },
  {
    id: 8,
    name: 'Assiette de fruits de mer',
    image: 'https://media-cdn.tripadvisor.com/media/photo-s/07/e7/a5/d3/restaurant-l-islandais.jpg',
    price: 24,
    type: 1
  },
  {
    id: 9,
    name: 'Mille feuille vanille',
    image: 'https://media-cdn.tripadvisor.com/media/photo-s/08/23/97/c9/le-mille-feuille.jpg',
    price: 10,
    type: 2
  },
  {
    id: 10,
    name: 'Sorbet fruité',
    image: 'https://media-cdn.tripadvisor.com/media/photo-s/0c/25/c3/c1/glace-3-sorbets-et-fruits.jpg',
    price: 7,
    type: 2
  },
  {
    id: 11,
    name: 'Moelleux au chaucolat',
    image: 'https://media-cdn.tripadvisor.com/media/photo-s/10/a5/6b/64/moelleux-au-chocolat.jpg',
    price: 9,
    type: 2
  },
  {
    id: 12,
    name: 'Spéciale dame blanche',
    image: 'https://www.ptitchef.com/imgupl/recipe/dame-blanche-la-glace-facile-ultra-gourmande--453699p703132.jpg',
    price: 9,
    type: 2
  }
]

module.exports = recettes
