<template>
   <div id="histoire">
     <nav class="menu" role="navigation">		
        <div class="inner">		
          <div class="m-left">
            <p>{{commandeoption.monEmail}}</p>
          </div>
          <div class="m-right">
             <router-link to='/' class="m-link">Accueil</router-link>
             <router-link to='/histoire' class="m-link">Histoire du site</router-link>
             <router-link to='/Menu' class="m-link">Menu</router-link>
             <router-link to='/commande' class="m-link">Ma commande</router-link>
             <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
          </div>	                				
        </div>			
      </nav>
      <div class="contenu">
        <div class="article">
			<h1 id="center"><b>Histoire du Karestom</b></h1>
			<p class="_p1"> Apprenez-en un peu plus sur le restaurant de <b>Tom et Karis</b> !</p>
			<hr class="solid">
			<p><b>Karestom</b> est un restaurant se situant dans le 6ème arrondissement de Paris, et proposant une gamme de plats variés. Il a été construit durant la période du COVID-19 afin de répondre aux besoins de se faire un plaisir, tout en évitant le contact humain qui est devenu dangereux.</p>

			<p> Sa construction a duré 1 prêt aujourd'hui à vous offrir ses portes ! En espérant que vous apprécierez les plats que nous proposons, nous vous souhaitons une bonne continuation.
			<div id="center">
				<video width=320  height=240 controls>
					<source src="videoprojet.mp4" type="video/mp4">
				</video>
			<p><em>Cordialement,</em></p>

			<em>Tom & Karis</em> </p>
			<hr>
            </div>
		</div>
       </div>
       <div><p id="invisible">.</p></div>
    </div> 
</template>

<script>
module.exports = {
  props: {
    commandeoption: {type: Object}
  },
  data () {
    return {   
    }
  },
  methods: {
    
  }
}
</script>

<style scoped>

#histoire{
    background-color:rgb(82, 16, 16);
}


.article
{
	color: black;
	width: 50%;
	background-color: white;
	margin: auto;
	margin-top: 50px;
	margin-bottom: 50px;
	border: solid black;
	border-radius: 2%;
    padding: 10px;
    margin-bottom:15px;
	height: auto;
	font-family: monospace;
}

.article:hover{
	position: relative;/* Pour déplacer le main*/
	top: 40px; 
	right: 40px;
	box-shadow: 60px -16px #484848; /*Créer l'effet de gris derrière*/
}


hr.solid {
  border-top: 3px solid black;
}

#center{
	text-align: center;
}

#invisible{
    opacity:0;
}

</style>