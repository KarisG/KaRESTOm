const express = require('express')
const router = express.Router()
const recettes = require('../data/recettes.js')


const bcrypt = require('bcrypt')
const { Client } = require('pg')



const client = new Client({
    user: 'postgres',
    host: 'localhost',
    password: 'password',
    database: 'Projet'
})

client.connect()

class Recette {
  constructor () {
    this.createdAt = new Date()
    this.updatedAt = new Date()
    this.recettes = []
  }
}



router.use((req, res, next) => {
  // l'utilisateur n'est pas reconnu, lui attribuer une commande dans req.session
  if (typeof req.session.commande === 'undefined') {
    req.session.commande = new Recette()
  }
  next()
})


/*route de Register
Elle récupère les informations entrées sur le site
Si l'email existe déjà dans la table users de notre base de données PgAdmin, on renvoie une erreur car deux utilisateurs ne peuvent pas utiliser la même adresse email
Sinon on hash le mot de passe donné par l'utilisateur et on stoque les deux informations dans la table users.
*/
router.post('/register', async (req, res) => {

  const email = req.body.email
  const password = req.body.password

  if (typeof email !== 'string' || email === '' ||
      typeof password !== 'string' || password === '') {
    //on retourne un message pour savoir si nous avons réussi à nous connecter
    res.json({message: "not connected"})
  }

  const users = await client.query({
    text: 'SELECT * FROM users'
  })
  
  const user = users.rows.find(u => u.email === email)
  if(user){
    res.json({message: "not connected"})
  }

  const hash = await bcrypt.hash(password, 10)

  await client.query({
    text: 'INSERT INTO users (email, password) VALUES ($1, $2)',
    values: [email, hash]
  })

  res.json({message : "connected"})
  
})


/*route de login
Elle récupère les informations entrées sur le site
Si l'email n'existe pas dans la table users de notre base de données PgAdmin on renvoie une erreur
Sinon on compare le mot de passe donné par l'utilisateur ainsi que le mot de passe hasher stocké sur le site
Si ils sont identiques, l'authentification est validé.
*/
router.post('/login', async (req, res) => {

  const email = req.body.email
  const password = req.body.password

  if (typeof email !== 'string' || email === '' ||
      typeof password !== 'string' || password === '') {
        //on retourne un message pour savoir si nous avons réussi à nous connecter
        res.json({message: "not connected"})
  }

  const users = await client.query({
    text: 'SELECT * FROM users'
  })
  
  const user = users.rows.find(u => u.email === email)
  if(!user){
    res.json({message: "not connected"})
  }

  const isSame = await bcrypt.compare(password,user.password)

  if(isSame){
    req.session.userId = user.id
    res.json({message : "connected"})
  }else{
    res.json({message: "not connected"})
  }
})

router.delete('/deconnexion', (req, res) => {
  req.session.userId = null;
  res.send()
})

// route permettante de savoir si un utilisateur est connecté ainsi que de connaitre son identité
router.get('/me', (req,res) => {
    res.json(req.session.userId)
})

// route renvoie l'adresse email correspondant à l'utilisateur connecté s'il l'est
router.get('/myemail', async (req,res) => {

  const users = await client.query({
    text: 'SELECT * FROM users'
  })
  
  const user = users.rows.find(u => u.id === req.session.userId)
  if(user){
    res.json(user.email)
  }
  else{
    res.status(400).json({ message: 'not connected'})
    return
  }
})

/*
 * Cette route doit retourner la commande de l'utilisateur, grâce à req.session
 */
router.get('/commande', (req, res) => {
  res.json(req.session.commande)
})

/*
  Cette route ajoute une recette à la commande de l'utilisateur (utilisée si la recette n'appartient pas à la commande)
 */
router.post('/commande', (req, res) => {

  const recetteId = parseInt(req.body.id)
  

  if (isNaN(recetteId)) {
    res.status(400).json({ message: 'recetteId should be a number' })
    return
  }
 
  //on regarde si la recette existe dans la carte
  const recette = recettes.find(a => a.id === recetteId)  
  if (!recette) {
    res.status(404).json({ message: 'recette ' + recetteId + ' does not exist' })
    return
  }

  //on regarde si la commande contient déjà la recette
  const inCommande = req.session.commande.recettes.find(a => a.id === recetteId)

  //On ajoute si elle n'est pas dans la commande
  if(!inCommande){
    const temp = {id: recetteId,number: 1}
    req.session.commande.recettes.push(temp)
    res.json(temp)
  }
  else{
    res.status(404).json({ message: 'bad request' })
    return
  }
     
})

/*
  Cette route incrémente le nombre de fois qu'une recette est commandée (utilisée lorsque la recette ajoutée à la commande est déjà présente dans celle-ci)
*/
router.put('/commande/increase/:recetteId', (req, res) => {

  const recetteId = parseInt(req.params.recetteId)
  
  if (isNaN(recetteId)) {
    res.status(400).json({ message: 'recetteId should be a number' })
    return
  }
  
  //on regarde si la recette est dans la commande
  const recette = req.session.commande.recettes.find(a => a.id === recetteId)
  if (!recette) {
    res.status(404).json({ message: 'recette ' + recetteId + ' does not exist' })
    return
  }

  
  //on met à jour la valeur
  req.session.commande.recettes.find(a => a.id === recetteId).number++
  res.send()
 
})




/*
  Cette route décrémente le nombre de fois qu'une recette est commandée (utilisée lorsque la recette retirée de la commande est présente plus d'une fois)
 */
router.put('/commande/reduce/:recetteId', (req, res) => {

  const recetteId = parseInt(req.params.recetteId)
  
  if (isNaN(recetteId)) {
    res.status(400).json({ message: 'recetteId should be a number' })
    return
  }
  
  //on regarde si la recette est dans la commande
  const recette = req.session.commande.recettes.find(a => a.id === recetteId)
  if (!recette) {
    res.status(404).json({ message: 'recette ' + recetteId + ' does not exist' })
    return
  }

  req.session.commande.recettes.find(a => a.id === recetteId).number--
  res.send()
 
})


/*
 * Cette route doit supprimer une recette de la commande (utilisée si la recette est présente une seule fois dans la commande)
 */
router.delete('/commande/:recetteId', (req, res) => {


  const recetteId = parseInt(req.params.recetteId)
  
  
  if (isNaN(recetteId)) {
    res.status(400).json({ message: 'recetteId should be a number' })
    return
  }
  
  //on regarde si la recette est bien dans la commande
  const recette = req.session.commande.recettes.find(a => a.id === recetteId)
  if (!recette) {
    res.status(404).json({ message: 'recette ' + recetteId + ' does not exist' })
    return
  }


  const index = req.session.commande.recettes.findIndex(a => a.id === recetteId)

  req.session.commande.recettes.splice(index, 1) // remove the article from the array
  res.send()

})


//la fonction décommander va vider la commande
router.delete('/commande', (req, res) => {

  req.session.commande.recettes.splice(0, req.session.commande.recettes.length)
  res.send()

})


/*
 * Cette route doit permettre de confirmer une commande, en recevant le nom et prénom de l'utilisateur
 * La commande est ensuite supprimé grâce à req.session.destroy()
 */
router.post('/commande/valider', (req, res) => {

  if(!req.session.userId){
    res.json({message: 'Vous n\'êtes pas connecté'})
    return
  }
  else if(req.session.commande.recettes.length == 0){
    res.json({message: 'Votre commande est vide'})
    return
  }
  else{
    req.session.destroy()
    res.json({message : 'validé'})
  }
})



/**
 * Cette route envoie l'intégralité des recettes du site
 */
router.get('/recettes', (req, res) => {
  res.json(recettes)
})



/**
 * Cette route crée une recette.
 * On vérifie que l'utilisateur soit connecté en tant qu'administrateur
 */
router.post('/recette', async (req, res) => {
  const name = req.body.name
  const image = req.body.image
  const price = parseInt(req.body.price)
  const type = parseInt(req.body.type)
  
  const users = await client.query({
    text: 'SELECT * FROM users'
  })
  
  const user = users.rows.find(u => u.email === "tom.gaultier@efrei.net")

  if(req.session.userId != user.id){
    res.status(400).json({ message: 'need to be connected as moderator' })
    return
  }

  // vérification de la validité des données d'entrée
  if (typeof name !== 'string' || name === '' ||
      typeof image !== 'string' || image === '' ||
      isNaN(price) || price <= 0 ||
      isNaN(type) || type < 0 || type > 2){
    res.status(400).json({ message: 'bad request' })
    return
  }

  const recette = {
    id: recettes.length + 1,
    name: name,
    image: image,
    price: price,
    type: type    
  }
  recettes.push(recette)
  // on envoie la recette ajouté à l'utilisateur
  res.json(recette)
})

/**
 * Cette fonction fait en sorte de valider que la recette demandé par l'utilisateur
 * est valide. Elle est appliquée aux routes:
 * - GET /recette/:recetteId
 * - PUT /recette/:recetteId
 * - DELETE /recette/:recetteId
 * Comme ces trois routes ont un comportement similaire, on regroupe leurs fonctionnalités communes dans un middleware
 */
function parseRecette (req, res, next) {
  const recetteId = parseInt(req.params.recetteId)

  // si articleId n'est pas un nombre (NaN = Not A Number), alors on s'arrête
  if (isNaN(recetteId)) {
    res.status(400).json({ message: 'recetteId should be a number' })
    return
  }
  // on affecte req.articleId pour l'exploiter dans toutes les routes qui en ont besoin
  req.recetteId = recetteId

  const recette = recettes.find(a => a.id === req.recetteId)
  if (!recette) {
    res.status(404).json({ message: 'recettte ' + recetteId + ' does not exist' })
    return
  }
  // on affecte req.article pour l'exploiter dans toutes les routes qui en ont besoin
  req.recette = recette
  next()
}

router.route('/recette/:recetteId')
  /**
   * Cette route envoie une recette particuliere
   */
  .get(parseRecette, (req, res) => {
    // req.article existe grâce au middleware parseRecette
    res.json(req.recette)
  })

  /*
  Cette route met à jour le prix de la recette sélectionné
   */
  .put(parseRecette, (req, res) => {
    const price = parseInt(req.body.price)

    if(isNaN(price)){
      res.status(400).json({ message: 'price should be a number' })
      return
    }

    req.recette.price = price
    
    res.send()
  })

  .delete(parseRecette, (req, res) => {
    const index = recettes.findIndex(a => a.id === req.recetteId)

    recettes.splice(index, 1) // supprime la recette du tableau des recettes
    res.send()
  })

module.exports = router
