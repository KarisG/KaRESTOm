<template>
  <div>
    <nav class="menu" role="navigation">		
      <div class="inner">		
        <div class="m-left">
           <p>{{commandeoption.monEmail}}</p>
        </div>
        <div class="m-right">
            <router-link to='/' class="m-link">Accueil</router-link>
            <router-link to='/histoire' class="m-link">Histoire du site</router-link>
            <router-link to='/Menu' class="m-link">Menu</router-link>
            <router-link to='/commande' class="m-link">Ma commande</router-link>
            <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
        </div>	                				
      </div>			
    </nav>
    <div class="contenu">
      <div class="carte">
        <div>
          <h2>Menu</h2>
          <!-- fonction commander appelle la route du meme nom pour regarder si l'utilisateur est connecté grace à la route get('api/me') qui renvoie l'id-->
          <button class="buttonCenter" @click="commander()" v-if="commandeoption.CommandeEtat == false">Commander</button>
          <button class="buttonCenter" @click="decommander()" v-else>Annuler ma commande</button>
        </div>
      
        <p v-if="commandeoption.CommandeEtat == true">{{commandeoption.prix}} €</p>
        <div class="fond">
            <h2>Nos formules </h2>
            <p v-if="commandeoption.CommandeEtat == true">Nous devons réserver pour combien de personnes ? <input type="text" v-model="commandeoption.Nbpersonnes"></p>

            
            <div>
              <p><strong>Modéré</strong> : Entrée + plat   {{PrixModere}}€</p>
              <div v-if="commandeoption.CommandeEtat == true"> 
                <p><button @click="modereup()">+</button><button @click="moderedown()">-</button> {{commandeoption.MenuModere}}</p>
              </div> 
            </div>

            <div>
              <p><strong>Gourmant</strong> : plat + dessert   {{PrixGourmant}}€ </p>
              <div v-if="commandeoption.CommandeEtat == true">
                <p><button @click="gourmantup()">+</button><button @click="gourmantdown()">-</button> {{commandeoption.MenuGourmant}}</p>
              </div>
            </div>
            
            <div>
              <p><strong>Gourmet</strong> : Entrée + plat + dessert  {{PrixGourmet}}€ </p>
              <div v-if="commandeoption.CommandeEtat == true">
                <p><button @click="gourmetup()">+</button><button @click="gourmetdown()">-</button> {{commandeoption.MenuGourmet}}</p>
              </div>
            </div>

        </div>
        <div class="fond">
            <h2>Les entrées</h2>
            <div v-for="recette in recettes" :key="recette.id">
                <div v-if="recette.type == 0">
                  <div class="recette-img">
                    <div :style="{ backgroundImage: 'url(' + recette.image + ')' }">
                    </div>
                  </div>
                  <div>
                      <p v-if="commandeoption.CommandeEtat == false">{{recette.name}}</p>
                      <div v-if="commandeoption.CommandeEtat == true">
                        <p>{{recette.name}}
                          <button  @click="addToCommande(recette.id)">Ajouter</button>
                          <button  @click="removeToCommande(recette.id)">Retirer</button>
                          {{recette.price}}€
                        </p>
                      </div>
                      <div>
                        <button @click="deleteRecette(recette.id)" v-if="commandeoption.ModifEtat == true">Supprimer</button>
                        <button @click="editRecette(recette)" v-if="commandeoption.ModifEtat == true">Modifier</button>
                        <div v-if="recette.id == editingRecette.id"> 
                              <input type="number" v-model="editingRecette.price" placeholder="Saisir le nouveau prix" >
                              <button @click="Editing()">Valider</button>
                              <button @click="AnnulerEditing()">Annuler</button>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="fond">
            <h2>Les plats</h2>
            <div v-for="recette in recettes" :key="recette.id">
                <div v-if="recette.type == 1">
                    <div class="recette-img">
                      <div :style="{ backgroundImage: 'url(' + recette.image + ')' }">
                      </div>
                    </div>
                    <div>
                      <p v-if="commandeoption.CommandeEtat == false">{{recette.name}}</p>
                      <div v-if="commandeoption.CommandeEtat == true">
                        <p>{{recette.name}} 
                          <button  @click="addToCommande(recette.id)">Ajouter</button>
                          <button  @click="removeToCommande(recette.id)">Retirer</button>
                          {{recette.price}}€
                        </p>
                      </div>
                      <div>
                        <button @click="deleteRecette(recette.id)" v-if="commandeoption.ModifEtat == true">Supprimer</button>
                        <button @click="editRecette(recette)" v-if="commandeoption.ModifEtat == true">Modifier</button>
                        <div v-if="recette.id == editingRecette.id"> 
                              <input type="number" v-model="editingRecette.price" placeholder="Saisir le nouveau prix" >
                              <button @click="Editing()">Valider</button>
                              <button @click="AnnulerEditing()">Annuler</button>
                        </div>
                      </div>
                    </div>   
                </div>
            </div>
        </div>
        <div class="fond">
            <h2>Les desserts</h2>
            <div v-for="recette in recettes" :key="recette.id">
                <div v-if="recette.type == 2">
                  <div class="recette-img">
                    <div :style="{ backgroundImage: 'url(' + recette.image + ')' }">
                    </div>
                  </div>
                  <div>
                      <p v-if="commandeoption.CommandeEtat == false">{{recette.name}}</p>
                      <div v-if="commandeoption.CommandeEtat == true">
                        <p>{{recette.name}}
                          <button  @click="addToCommande(recette.id)">Ajouter</button>
                          <button  @click="removeToCommande(recette.id)">Retirer</button>
                          {{recette.price}}€
                        </p>
                      </div>
                      <div>
                        <button @click="deleteRecette(recette.id)" v-if="commandeoption.ModifEtat == true">Supprimer</button>
                        <button @click="editRecette(recette)" v-if="commandeoption.ModifEtat == true">Modifier</button>
                        <div v-if="recette.id == editingRecette.id"> 
                              <input type="number" v-model="editingRecette.price" placeholder="Saisir le nouveau prix" >
                              <button @click="Editing()">Valider</button>
                              <button @click="AnnulerEditing()">Annuler</button>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
      </div>  
      <div>
           <!--la fonction modifier appelle la route du get('api/myemail') pour savoir si le compte connecté est celui de l'administrateur -->
          <button class="buttonCenter" @click="modifier()" v-if="commandeoption.ModifEtat == false">Modifier le Menu</button>
          <button class="buttonCenter" @click="annulerModif()" v-else>Annuler la modification</button>
      </div>
      <form v-if="commandeoption.ModifEtat == true">
        <h2>Nouvelle recette à ajouter</h2>
        <input type="text" v-model="newRecette.name" placeholder="Nom de la recette" required>
        <input type="number" v-model="newRecette.price" placeholder="Prix" required>
        <input type="text" v-model="newRecette.image" placeholder="Lien vers l'image" required>
        <input type="number" v-model="newRecette.type" placeholder="Type de la recette : 0 (entrée), 1(plat), 2(dessert)" required>
        <button type="submit" @click="addToRecettes()">Ajouter</button>
      </form>
     </div>
  </div>
</template>

<script>

module.exports = {
  props: {
    commandeoption: {type: Object},
    recettes: { type: Array, default: [] },
    commande: { type: Object } 
  },
  data () {
    return {
      PrixModere: 33,
      PrixGourmant: 27,
      PrixGourmet: 40,
      newRecette: {
        name: '',
        image: '',
        price: 0,
        type: 0
      },
      editingRecette: {
        id: 0,
        price: 0
      }
    }
  },
  async mounted () {
  },
  methods: {
    //changer la vision de la page pour accéder aux boutons de commande (besoin d'être connecté)
    commander(){
      this.$emit('commander')
    },
    //annule la commande et reviens à la vision de base (juste le menu)
    decommander(){
      this.$emit('decommander')
    },
    //permet d'avoir accès aux boutons de modifications (nécessite d'être connecté en tant que modérateur (email = tom.gaultier@gmail.com))
    modifier(){
      this.$emit('modifier')
      this.$emit('decommander')
    },
    //annule les modifications
    annulerModif(){
      this.$emit('annulermodif')
      this.newRecette =  {
        name: '',
        image: '',
        price: 0,
        type: 0
      }
    },
    //ajoute la recette au menu
    addToRecettes(){
      this.$emit('add-to-recettes', this.newRecette)
      this.newRecette =  {
        name: '',
        image: '',
        price: 0,
        type: 0
      }
    },
    //sélectionner une recette pour modifier son prix
    editRecette(recette){
      this.editingRecette.id = recette.id
      this.editingRecette.price = recette.price
    },
    //annuler la modification d'une recette
    AnnulerEditing(){
      this.editingRecette = {
        id: 0,
        price: 0
      }
    },
    //modifiel le prix de la recette
    Editing(){
      this.$emit('changer-prix', this.editingRecette)
      this.AnnulerEditing()
    },
    deleteRecette(recetteId){
      this.$emit('delete-recette', recetteId)
    },
    modereup(){
      if(this.commandeoption.Nbpersonnes > 0){
        this.commandeoption.MenuModere++
        this.commandeoption.Nbpersonnes--
        this.commandeoption.Nbentrees++
        this.commandeoption.Nbplats++
        this.commandeoption.prix += this.PrixModere
      }
    },
    moderedown(){
      if(this.commandeoption.MenuModere > 0){
        this.commandeoption.MenuModere--
        this.commandeoption.Nbpersonnes++
        this.commandeoption.Nbentrees--
        this.commandeoption.Nbplats--
        this.commandeoption.prix -= this.PrixModere
      }
    },
    gourmantup(){
      if(this.commandeoption.Nbpersonnes > 0){
        this.commandeoption.MenuGourmant++
        this.commandeoption.Nbpersonnes--
        this.commandeoption.Nbplats++
        this.commandeoption.Nbdesserts++
        this.commandeoption.prix += this.PrixGourmant
      }
    },
    gourmantdown(){
      if(this.commandeoption.MenuGourmant > 0){
        this.commandeoption.MenuGourmant--
        this.commandeoption.Nbpersonnes++
        this.commandeoption.Nbplats--
        this.commandeoption.Nbdesserts--
        this.commandeoption.prix -= this.PrixGourmant
      }
    },
    gourmetup(){
      if(this.commandeoption.Nbpersonnes > 0){
        this.commandeoption.MenuGourmet++
        this.commandeoption.Nbpersonnes--
        this.commandeoption.Nbentrees++
        this.commandeoption.Nbplats++
        this.commandeoption.Nbdesserts++
        this.commandeoption.prix += this.PrixGourmet
      }
    },
    gourmetdown(){
      if(this.commandeoption.MenuGourmet > 0){
        this.commandeoption.MenuGourmet--
        this.commandeoption.Nbpersonnes++
        this.commandeoption.Nbentrees--
        this.commandeoption.Nbplats--
        this.commandeoption.Nbdesserts--
        this.commandeoption.prix -= this.PrixGourmet
      }
    },
    addToCommande(recetteId){

      recette = this.recettes.find(a => a.id === recetteId)

      switch(recette.type){
        case 0:
          if(this.commandeoption.Nbentrees < 1){
            this.commandeoption.prix += recette.price
          }
          this.commandeoption.Nbentrees--
          break
        case 1:
          if(this.commandeoption.Nbplats < 1){
            this.commandeoption.prix += recette.price
          }
          this.commandeoption.Nbplats--
          break
        case 2:
          if(this.commandeoption.Nbdesserts < 1){
            this.commandeoption.prix += recette.price
          }
          this.commandeoption.Nbdesserts--
          break
        default:
          break
      }
      
      inCommande = this.commande.recettes.find(a => a.id === recetteId)
      if(inCommande){
        this.$emit('increase-number-in-commande', recetteId)
      }
      else{
        this.$emit('add-to-commande', recetteId)
      }
      
    },
    removeToCommande(recetteId){

      recette = this.recettes.find(a => a.id === recetteId)

      recetteCommande = this.commande.recettes.find(a => a.id === recetteId)

      if(recetteCommande){

        switch(recette.type){
          case 0:
            if(this.commandeoption.Nbentrees < 0){
              this.commandeoption.prix -= recette.price
            }
            this.commandeoption.Nbentrees++
            break
          case 1:
            if(this.commandeoption.Nbplats < 1){
              this.commandeoption.prix -= recette.price
            }
            this.commandeoption.Nbplats++
            break
          case 2:
            if(this.commandeoption.Nbdesserts < 1){
              this.commandeoption.prix -= recette.price
            }
            this.commandeoption.Nbdesserts++
            break
          default:
            break
        }
        
        if(recetteCommande.number <= 1){
          this.$emit('remove-to-commande', recetteId)
        }
        else{
          this.$emit('reduce-number-in-commande', recetteId)
        }
        
      }
    }
  }
}
</script>

<style scoped>



</style>
