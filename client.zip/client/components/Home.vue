<template>
   <div id="home">
     <nav class="menu" role="navigation">		
        <div class="inner">		
          <div class="m-left">
            <p>{{commandeoption.monEmail}}</p>
          </div>
          <div class="m-right">
             <router-link to='/' class="m-link">Accueil</router-link>
             <router-link to='/histoire' class="m-link">Histoire du site</router-link>
             <router-link to='/menu' class="m-link">Menu</router-link>
             <router-link to='/commande' class="m-link">Ma commande</router-link>
             <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
          </div>	                				
        </div>			
      </nav>
      <div class="contenu">
        <div id="ImgGauche">
          <p>Une des plus belles vue de Paris</p>
          <img class="map" src="restaurant.jpg"/>
        </div> 
        <div id="ImgDroit">
          <p>Vous pouvez retrouver le Kareston au sixième arrondissement par le metreo 4 ou 12</p>
          <img class="map" src="map.jpg"/>
        </div> 
        <div id="normal">
          <h2>Nos Prix</h2>
          <p>3ème meilleur rooftops Parisien en 2016</p>
          <p>2ème à la coupe de france du burger 2014</p>
        </div> 
      </div>
    </div> 
</template>

<script>
module.exports = {
  props: {
    commandeoption: {type: Object}
  },
  data () {
    return {
     
    }
  },
  methods: {
    
  }
}
</script>

<style scoped>

#home{
  background-color:rgb(82, 16, 16);
}

.map{
  width: 1000px;
	height: 698px;
	margin-right: auto;
	margin-left: auto;
}

#ImgGauche{
  float:left;
  margin-left:1em;
  text-align:center;
}

#ImgDroit{
  float:right;
  margin-right:1em;
  text-align:center;
}

#normal{
  margin-top:1700px;
  padding-bottom:20px;
  clear:right;
}

p, h2{
  color:white;
}

</style>