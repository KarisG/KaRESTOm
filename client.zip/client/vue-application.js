const Home = window.httpVueLoader('./components/Home.vue')
const Menu = window.httpVueLoader('./components/Menu.vue')
const Commande = window.httpVueLoader('./components/Commande.vue')
const Histoire = window.httpVueLoader('./components/Histoire.vue')
const Connexion = window.httpVueLoader('./components/Connexion.vue')
const Register = window.httpVueLoader('./components/Register.vue')
const Login = window.httpVueLoader('./components/Login.vue')

const routes = [
  { path: '/', component: Home },
  { path: '/menu', component: Menu },
  { path: '/commande', component: Commande },
  { path: '/histoire', component: Histoire},
  { path : '/connexion', component: Connexion},
  { path : '/register', component: Register},
  { path : '/login', component: Login}
]

const router = new VueRouter({
  routes
})

var app = new Vue({
  router,
  el: '#app',
  data: {
    commandeoption: {
      prix: 0,
      Nbpersonnes: 0, //nombre de personnes qui vont manger
      MenuModere: 0,  //nombre de menu modéré
      MenuGourmant: 0, //nombre de menu gourmant
      MenuGourmet: 0, //nombre de menu gourmet
      Nbentrees: 0,
      Nbplats: 0,
      Nbdesserts: 0,
      CommandeEtat: false,  //savoir si l'utilisateur est en train de commander pour afficher les boutons
      ModifEtat: false,      //savoir si l'utilisateur est admin et est en train de modifier le menu
      monEmail: ''
    },
    recettes: [],
    commande: {
      createdAt: null,
      updatedAt: null,
      recettes: []
    }
  },
  async mounted () {
    const res = await axios.get('/api/recettes')
    this.recettes = res.data
  },
  methods: {
    async addToRecettes (recette) {
      const res = await axios.post('/api/recette', recette)
      if(res.data){
        this.recettes.push(res.data)
      }
      
    },
    //changer le prix d'une recette, accédé seulement si connecté en temps qu'admin
    async changerPrix (recette) {
      await axios.put('/api/recette/' + recette.id, recette)
      const r = this.recettes.find(a => a.id === recette.id)
      r.price = recette.price
    },
    //supprime une recette du menu, accédé seulement si connecté en temps qu'admin
    async deleteRecette (recetteId) {
      await axios.delete('/api/recette/' + recetteId)
      const index = this.recettes.findIndex(a => a.id === recetteId)
      this.recettes.splice(index, 1)
    },
    //permet d'ajouter une recette à la commande, accédé seulement si connecté
    async addToCommande(recetteId){
      
      const res = await axios.post('/api/commande', {id: recetteId})
      this.commande.recettes.push(res.data)
    },
    //permet de supprimer une recette de la commande, accédé seulement si connecté
    async removeToCommande(recetteId){

      const res = await axios.delete('/api/commande/' + recetteId)
      const index = this.commande.recettes.findIndex(a => a.id === recetteId)
      this.commande.recettes.splice(index, 1)

    },
    //réduit le nombre de fois qu'une recette est dans la commande, s'il existe un exemplaire, on utilisera la fonction removeToCommande
    async reduceInCommande(recetteId){
      await axios.put('/api/commande/reduce/' + recetteId)
      this.commande.recettes.find(a => a.id === recetteId).number--
    },
    //augmente le nombre de fois qu'une recette est dans la commande
    async increaseInCommande(recetteId){
      await axios.put('/api/commande/increase/' + recetteId)
      this.commande.recettes.find(a => a.id === recetteId).number++
    },
    //décommander restaure l'objet commandeoption
    async decommander(){
      this.commandeoption = {
        prix: 0,
        Nbpersonnes: 0, //nombre de personnes qui vont manger
        MenuModere: 0,  //nombre de menu modéré
        MenuGourmant: 0, //nombre de menu gourmant
        MenuGourmet: 0, //nombre de menu gourmet
        Nbentrees: 0,
        Nbplats: 0,
        Nbdesserts: 0,
        CommandeEtat: false,
        ModifEtat: false,
        monEmail: ''
      }
      //on vide la commande
      this.commande.recettes.splice(0,this.commande.recettes.length)
      await axios.delete('/api/commande')
    },
    //on cherche à accéder à la commander si l'utilisateur est connecté
    async commander(){
      const res = await axios.get('api/me')
      //on regarde si l'id retourner par la route est bien un entier
      if(typeof res.data == 'number'){
        this.commandeoption.CommandeEtat = true
      }
    },
    async modifier(){
      const res = await axios.get('api/myemail')
      //on regarde si l'id retourner par la route est bien un entier
      if(res.data == "tom.gaultier@efrei.net"){
        this.commandeoption.ModifEtat = true
      }else{
        alert("Vous devez être connecté en temps qu'administrateur")
      }
    },
    async annulerModif(){
      this.commandeoption.ModifEtat = false
    },
    //la route regarde s'il n'y a pas de compte avec cette email pour créer un compte
    //affiche une alerte pour l'utilisateur
    async addUser(user){
      const res = await axios.post('api/register', {email: user.email,password: user.password})
      if(res.data.message == "connected"){
        alert("Inscription validée !")
      }
      else{
        alert("Adresse email déjà utilisée")
      }
    },
    //la route regarde s'il existe un compte avec cette email et si le mot de passe est bon pour se connecté
    //affiche une alerte pour l'utilisateur
    async Connexion(user){
      const res = await axios.post('api/login', {email: user.email,password: user.password})
      if(res.data.message == "connected"){
        alert("Vous êtes connecté !")
        const res2 = await axios.get('api/myemail')
        this.commandeoption.myEmail = res2.data
      }
      else{
        alert("Erreur : Email ou mot de passe incorrect")
      }
    },
    async Deconnexion(){
      await axios.delete('api/deconnexion')
    },
    async validerCommande(){
      const res = await axios.post('api/commande/valider')
      if(res.data.message == "validé"){
        alert("Merci, votre commande de " + this.commandeoption.prix + "€ a bien été pris en compte.")
      }
      else{
        alert(res.data.message);
      }
      this.decommander()
    }
  }
})
