<template>
    <div>
        <nav class="menu" role="navigation">		
            <div class="inner">
                <div class="m-left">
                    <p>{{commandeoption.monEmail}}</p>
                </div>	
                <div class="m-right">
                    <router-link to='/' class="m-link">Accueil</router-link>
                    <router-link to='/histoire' class="m-link">Histoire du site</router-link>
                    <router-link to='/Menu' class="m-link">Menu</router-link>
                    <router-link to='/commande' class="m-link">Ma commande</router-link>
                    <router-link to='/connexion' class="m-link">Me connecter</router-link> 	
                </div>	                				
            </div>			
        </nav>
        <div class="contenu">
            <div class="fond">
                <p><button><router-link to='/login'>Se connecter</router-link></button> Vous avez déjà un compte ? </p>
                <p><button><router-link to='/register'>S'inscrire</router-link></button> Si vous n'avez pas encore de compte, rejoignez-nous</p>
                <button class="buttonCenter" @click="deconnexion()">Se déconnecter</button>  
            </div>
        </div>
    </div>
</template>

<script>
module.exports={
    props: {
        commandeoption: {type: Object},
        recettes: { type: Array, default: [] },
        commande: { type: Object },
    },
    data () {
        return {
            user: {
                email: '',
                password: ''
            },
            vision: 0
        }
  },
  methods: { 
    deconnexion: function(){
        this.$emit('deconnexion')
    }
  }
}
</script>

<style scoped>


</style>